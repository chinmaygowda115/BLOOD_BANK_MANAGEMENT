# Blood_Bank_Management_System
A project made as a part of the Database Management System Course (UE20CS301) at PES University. The objective of the project was to demonstrate the Website Application With DATABASE 
